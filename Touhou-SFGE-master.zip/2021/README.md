# 【2021·东方华灯宴】节目表
[【正片】2021·东方华灯宴](https://www.bilibili.com/video/BV1Sy4y1Y773)

- 节目标题点击可直接跳转到华灯宴对应分P和时间点
- 时间一栏包含过场动画, 位于每个单品的开头
- 单品的 av / BV 链接点击可跳转到单品播放页面
- 嘉宾祝福3中包含东方栖霞园PV, 因此会有单品

## P1 牛年开气运
|节目|时间|时长|单品|
|----|----|----|----|
| [射命丸](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=0) | 00:00 ~ 02:44 | 02:44 | [av801731352](https://www.bilibili.com/video/av801731352) / [BV19y4y1E7BD](https://www.bilibili.com/video/BV19y4y1E7BD) |
| [开宴「流光惊鸿」](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=164) | 02:44 ~ 11:51 | 09:07 | / |
| [开场动画](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=711) | 11:51 ~ 12:53 | 01:02 | [av886663331](https://www.bilibili.com/video/av886663331) / [BV1YK4y1n7Vz](https://www.bilibili.com/video/BV1YK4y1n7Vz) |
| [主持1 - 灵梦, 魔理沙](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=773) | 12:53 ~ 13:31 | 00:38 | / |
| [广告环节](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=811) | 13:31 ~ 14:47 | 01:16 | / |
| [主持2 - 灵梦, 魔理沙](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=887) | 14:47 ~ 16:12 | 01:25 | / |
| [东方名曲发生了奇怪的BUG](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=972) | 16:12 ~ 23:07 | 06:55 | [av289249417](https://www.bilibili.com/video/av289249417) / [BV11f4y1z7Em](https://www.bilibili.com/video/BV11f4y1z7Em) |
| [生与死的境界](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=1387) | 23:07 ~ 33:05 | 09:58 | [av929186573](https://www.bilibili.com/video/av929186573) / [BV1sK4y1Q7h4](https://www.bilibili.com/video/BV1sK4y1Q7h4) |
| [嘉宾祝福1](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=1985) | 33:05 ~ 38:14 | 05:09 | / |
| [R.I.P.――Rest In Peace](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=2294) | 38:14 ~ 41:37 | 03:23 | [av374165570](https://www.bilibili.com/video/av374165570) / [BV1Wo4y197dD](https://www.bilibili.com/video/BV1Wo4y197dD) |
| [东方夜明歌](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=2497) | 41:37 ~ 48:36 | 06:59 | [av331675871](https://www.bilibili.com/video/av331675871) / [BV1RA411T7E9](https://www.bilibili.com/video/BV1RA411T7E9) |
| [主持3 - 小铃, 早苗](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=2916) | 48:36 ~ 49:54 | 01:18 | / |
| [学漫才](https://www.bilibili.com/video/BV1Sy4y1Y773?p=1&t=2994) | 49:54 ~ 66:12 | 16:18 | [av246658480](https://www.bilibili.com/video/av246658480) / [BV1Vv411v7F6](https://www.bilibili.com/video/BV1Vv411v7F6) |

## P2 转念聚吉祥
|节目|时间|时长|单品|
|----|----|----|----|
| [主持4 - 灵梦, 魔理沙, 小铃, 早苗](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=0) | 00:00 ~ 01:43 | 01:43 | / |
| [东方Project \~家庭教师~](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=103) | 01:43 ~ 06:49 | 05:06 | [av374187616](https://www.bilibili.com/video/av374187616) / [BV16o4y197q6](https://www.bilibili.com/video/BV16o4y197q6) |
| [爱丽丝梦游仙境](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=409) | 06:49 ~ 11:53 | 05:04 | [av501678706](https://www.bilibili.com/video/av501678706) / [BV1cN411d7GV](https://www.bilibili.com/video/BV1cN411d7GV) |
| [乱斗60秒: 十六夜 vs DIO](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=713) | 11:53 ~ 15:34 | 03:41 | [av289136509](https://www.bilibili.com/video/av289136509) / [BV1rf4y1r7jd](https://www.bilibili.com/video/BV1rf4y1r7jd) |
| [闻鸡起舞的凭依华捣蒜](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=934) | 15:34 ~ 19:39 | 04:05 | [av971714560](https://www.bilibili.com/video/av971714560) / [BV1Pp4y1W79y](https://www.bilibili.com/video/BV1Pp4y1W79y) |
| [嘉宾祝福2](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=1179) | 19:39 ~ 23:22 | 03:43 | / |
| [幻想乡打牌王](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=1402) | 23:22 ~ 53:14 | 29:52 | [av886656818](https://www.bilibili.com/video/av886656818) / [BV18K4y1n7yo](https://www.bilibili.com/video/BV18K4y1n7yo) |
| [主持5 - 小铃, 早苗](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=3194) | 53:14 ~ 54:34 | 01:20 | / |
| [人相「造型术」](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=3274) | 54:34 ~ 58:36 | 04:02 | [av586765596](https://www.bilibili.com/video/av586765596) / [BV1hz4y127GL](https://www.bilibili.com/video/BV1hz4y127GL) |
| [幻想游戏<花映塚连弹>](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=3516) | 58:36 ~ 67:46 | 09:10 | [av929246468](https://www.bilibili.com/video/av929246468) / [BV1QK4y1Q75t](https://www.bilibili.com/video/BV1QK4y1Q75t) |
| [对坐数来宝](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=4066) | 67:46 ~ 74:27 | 06:41 | [av246726090](https://www.bilibili.com/video/av246726090) / [BV1Qv411a7F7](https://www.bilibili.com/video/BV1Qv411a7F7) |
| [Daisuke](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=4467) | 74:27 ~ 77:12 | 02:45 | [av374198033](https://www.bilibili.com/video/av374198033) / [BV1ao4y197mE](https://www.bilibili.com/video/BV1ao4y197mE) |
| [红莲的夕岚](https://www.bilibili.com/video/BV1Sy4y1Y773?p=2&t=4632) | 77:12 ~ 81:33 | 04:21 | [av331635874](https://www.bilibili.com/video/av331635874) / [BV1rA411T7XA](https://www.bilibili.com/video/BV1rA411T7XA) |

## P3 乾道同和乐
|节目|时间|时长|单品|
|----|----|----|----|
| [幻葬梦华笺](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=0) | 00:00 ~ 02:50 | 02:50 | [av671704057](https://www.bilibili.com/video/av671704057) / [BV1nU4y1W7W9](https://www.bilibili.com/video/BV1nU4y1W7W9) |
| [玄星 \~Hidden Stars~](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=170) | 02:50 ~ 07:39 | 04:49 | [av799149401](https://www.bilibili.com/video/av799149401) / [BV16y4y1Y7hC](https://www.bilibili.com/video/BV16y4y1Y7hC) |
| [东游鉴的魔法书 \~新春特别篇~](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=459) | 07:39 ~ 19:03 | 11:24 | [av331699182](https://www.bilibili.com/video/av331699182) / [BV1AA411M7bc](https://www.bilibili.com/video/BV1AA411M7bc) |
| [饵](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=1143) | 19:03 ~ 22:02 | 02:59 | [av374334473](https://www.bilibili.com/video/av374334473) / [BV1Lo4y1R7eq](https://www.bilibili.com/video/BV1Lo4y1R7eq) |
| [东方萃梦想](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=1322) | 22:02 ~ 27:34 | 05:32 | [av756651265](https://www.bilibili.com/video/av756651265) / [BV1Fr4y1N7rv](https://www.bilibili.com/video/BV1Fr4y1N7rv) |
| [「Ｃｈｕ♡Ｃｈｕ♡Ｃｈｕ」](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=1654) | 27:34 ~ 31:10 | 03:36 | [av331786119](https://www.bilibili.com/video/av331786119) / [BV1zA411M78w](https://www.bilibili.com/video/BV1zA411M78w) |
| [主持6 - 魔理沙](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=1870) | 31:10 ~ 32:54 | 01:44 | / |
| [红魔馆不能有两个门卫](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=1974) | 32:54 ~ 37:24 | 04:30 | [av289133362](https://www.bilibili.com/video/av289133362) / [BV1kf4y1r7VA](https://www.bilibili.com/video/BV1kf4y1r7VA) |
| [嘉宾祝福3](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=2244) | 37:24 ~ 41:22 | 03:58 | [av756671778](https://www.bilibili.com/video/av756671778) / [BV1or4y1P7AL](https://www.bilibili.com/video/BV1or4y1P7AL) |
| [高级餐厅](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=2482) | 41:22 ~ 51:59 | 10:37 | [av844171986](https://www.bilibili.com/video/av844171986) / [BV1G54y1Y7ru](https://www.bilibili.com/video/BV1G54y1Y7ru) |
| [HAVE A NICE DAY](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=3119) | 51:59 ~ 56:37 | 04:38 | [av459324806](https://www.bilibili.com/video/av459324806) / [BV185411N7T3](https://www.bilibili.com/video/BV185411N7T3) |
| [流浪月球 II](https://www.bilibili.com/video/BV1Sy4y1Y773?p=3&t=3397) | 56:37 ~ 79:07 | 22:30 | [av374210253](https://www.bilibili.com/video/av374210253) / [BV1io4y197Ez](https://www.bilibili.com/video/BV1io4y197Ez) |

## P4 坤仪美景长
|节目|时间|时长|单品|
|----|----|----|----|
| [遊！祭り綺想曲](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=0) | 00:00 ~ 03:35 | 03:35 | [av929227515](https://www.bilibili.com/video/av929227515) / [BV1qK4y1Q7eK](https://www.bilibili.com/video/BV1qK4y1Q7eK) |
| [東方寶麗金: 歌行休回頭](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=215) | 03:35 ~ 08:31 | 04:56 | [av844146444](https://www.bilibili.com/video/av844146444) / [BV1N54y1Y7SA](https://www.bilibili.com/video/BV1N54y1Y7SA) |
| [鬼王聚会](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=511) | 08:31 ~ 16:44 | 08:13 | [av714154624](https://www.bilibili.com/video/av714154624) / [BV14X4y157fu](https://www.bilibili.com/video/BV14X4y157fu) |
| [请笃信一个梦](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=1004) | 16:44 ~ 21:29 | 04:45 | [av801673908](https://www.bilibili.com/video/av801673908) / [BV12y4y1E75L](https://www.bilibili.com/video/BV12y4y1E75L) |
| [嘉宾祝福4](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=1289) | 21:29 ~ 25:27 | 03:58 | / |
| [东方没嘻哈――灵梦vs八云紫](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=1527) | 25:27 ~ 29:17 | 03:50 | [av756733668](https://www.bilibili.com/video/av756733668) / [BV1Lr4y1N7J2](https://www.bilibili.com/video/BV1Lr4y1N7J2) |
| [DUOLOGUE: A FRIDAY CHAT](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=1757) | 29:17 ~ 36:29 | 07:12 | [av204170497](https://www.bilibili.com/video/av204170497) / [BV1Rh411C74E](https://www.bilibili.com/video/BV1Rh411C74E) |
| [夙愿](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=2189) | 36:29 ~ 40:39 | 04:10 | [av204191660](https://www.bilibili.com/video/av204191660) / [BV16y4y1Y7hC](https://www.bilibili.com/video/BV16y4y1Y7hC) |
| [老腔皮影戏《东方非想天则》](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=2439) | 40:39 ~ 66:03 | 25:24 | [av416680994](https://www.bilibili.com/video/av416680994) / [BV1CV411i7G7](https://www.bilibili.com/video/BV1CV411i7G7) |
| [无何有之乡](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=3963) | 66:03 ~ 71:12 | 05:09 | [av671649315](https://www.bilibili.com/video/av671649315) / [BV1GU4y1W7gb](https://www.bilibili.com/video/BV1GU4y1W7gb) |
| [挠痒痒地狱之刑](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=4272) | 71:12 ~ 75:07 | 03:55 | [av929217335](https://www.bilibili.com/video/av929217335) / [BV1CK4y1Q7gS](https://www.bilibili.com/video/BV1CK4y1Q7gS) |
| [华魂](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=4507) | 75:07 ~ 80:20 | 05:13 | [av929137958](https://www.bilibili.com/video/av929137958) / [BV1JK4y1Q7Gu](https://www.bilibili.com/video/BV1JK4y1Q7Gu) |
| [主持7 - 灵梦, 魔理沙, 小铃, 早苗](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=4820) | 80:20 ~ 82:36 | 02:16 | / |
| [幻想与宴会的民意](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=4956) | 82:36 ~ 95:09 | 12:33 | [av331646903](https://www.bilibili.com/video/av331646903) / [BV1oA411T7KG](https://www.bilibili.com/video/BV1oA411T7KG) |
| [祈新岁·灯未央 (Staff表)](https://www.bilibili.com/video/BV1Sy4y1Y773?p=4&t=5709) | 95:09 ~ 98:32 | 03:23 | [av374242238](https://www.bilibili.com/video/av374242238) / [BV12o4y197tA](https://www.bilibili.com/video/BV12o4y197tA) |